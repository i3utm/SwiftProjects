//
//  ViewController.swift
//  Light
//
//  Created by Micheal Crump on 2/21/21.
//  Copyright © 2021 Michael Crump. All rights reserved.
//

import UIKit

var lightOn = true
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func buttonPressed(_ sender: Any){
        lightOn.toggle()
        updateUI()
    }
    func updateUI(){
        view.backgroundColor = lightOn ? .white : .black
    }
}
